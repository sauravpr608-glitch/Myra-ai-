package com.myra.assistant.model

/**
 * MYRA — App Command
 * Structured representation of a voice/text command parsed from user speech.
 *
 * @param type   Command type string (e.g. "OPEN_APP", "CALL", "PRIME_CALL")
 * @param params Map of parameter key→value pairs relevant to the command
 */
data class AppCommand(
    val type: String,
    val params: Map<String, String>
) {
    companion object {
        // Command type constants
        const val OPEN_APP       = "OPEN_APP"
        const val CLOSE_APP      = "CLOSE_APP"
        const val CALL           = "CALL"
        const val SMS            = "SMS"
        const val WHATSAPP_CALL  = "WHATSAPP_CALL"
        const val WHATSAPP_MSG   = "WHATSAPP_MSG"
        const val PRIME_CALL     = "PRIME_CALL"
        const val PRIME_MSG      = "PRIME_MSG"
        const val VOLUME_UP      = "VOLUME_UP"
        const val VOLUME_DOWN    = "VOLUME_DOWN"
        const val FLASHLIGHT_ON  = "FLASHLIGHT_ON"
        const val FLASHLIGHT_OFF = "FLASHLIGHT_OFF"
        const val WIFI_ON        = "WIFI_ON"
        const val WIFI_OFF       = "WIFI_OFF"
        const val BLUETOOTH_ON   = "BLUETOOTH_ON"
        const val BLUETOOTH_OFF  = "BLUETOOTH_OFF"
    }
}

/**
 * Prime Contact stored as a serializable data class.
 */
data class PrimeContact(
    val name: String,
    val number: String
)
