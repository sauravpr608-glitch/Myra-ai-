package com.myra.assistant.ai

import com.myra.assistant.model.AppCommand

/**
 * MYRA — Command Parser
 * Parses transcribed speech (Hinglish + English) into structured AppCommand objects.
 */
object CommandParser {

    /**
     * Attempt to parse voice text into an AppCommand.
     * Returns null if no command is matched (let Gemini handle as conversation).
     */
    fun parse(text: String): AppCommand? {
        val t = text.trim().lowercase()

        // ─── App Open ───
        val openMatch = Regex(
            """(?:open|kholo|chalo|start|launch|chalao)\s+(.+)""",
            RegexOption.IGNORE_CASE
        ).find(t)
        if (openMatch != null) {
            val appName = openMatch.groupValues[1].trim().removeSuffix(" karo").removeSuffix(" kar")
            return AppCommand("OPEN_APP", mapOf("app_name" to appName))
        }

        // ─── App Close ───
        if (t.matchesAny("band karo", "close karo", "band kar", "close", "band")) {
            val closeMatch = Regex(
                """(.+?)\s+(?:band karo|band kar|band|close karo|close)""",
                RegexOption.IGNORE_CASE
            ).find(t)
            if (closeMatch != null) {
                val appName = closeMatch.groupValues[1].trim()
                return AppCommand("CLOSE_APP", mapOf("app_name" to appName))
            }
            return AppCommand("CLOSE_APP", mapOf("app_name" to "current"))
        }

        // ─── WhatsApp Actions ───
        val waCallMatch = Regex(
            """(.+?)\s+(?:ko|se)?\s*(?:whatsapp call|wa call|whatsapp pe call)""",
            RegexOption.IGNORE_CASE
        ).find(t)
        if (waCallMatch != null) {
            return AppCommand("WHATSAPP_CALL", mapOf("name" to waCallMatch.groupValues[1].trim()))
        }

        val waMsgMatch = Regex(
            """(.+?)\s+(?:ko)?\s*(?:whatsapp karo|whatsapp msg|whatsapp message|whatsapp pe message|wa msg)""",
            RegexOption.IGNORE_CASE
        ).find(t)
        if (waMsgMatch != null) {
            return AppCommand("WHATSAPP_MSG", mapOf("name" to waMsgMatch.groupValues[1].trim()))
        }

        // ─── Prime Contact Call ───
        val primeCallPatterns = listOf(
            "close friend ko call karo", "mere close friend ko call",
            "apne close friend ko call", "best friend ko call",
            "meri jaan ko call", "my close friend call",
            "call my close friend", "call my best friend",
            "prime contact call"
        )
        if (primeCallPatterns.any { t.contains(it) }) {
            val index = extractSecondaryIndex(t)
            return AppCommand("PRIME_CALL", mapOf("index" to index.toString()))
        }

        // ─── Prime Contact Message ───
        val primeMsgPatterns = listOf(
            "close friend ko msg", "close friend ko message",
            "meri jaan ko message", "meri jaan ko msg",
            "my close friend ko message", "message my love",
            "message my close friend", "prime contact ko message"
        )
        if (primeMsgPatterns.any { t.contains(it) }) {
            val index = extractSecondaryIndex(t)
            return AppCommand("PRIME_MSG", mapOf("index" to index.toString()))
        }

        // ─── Call by Name ───
        val callMatch = Regex(
            """(?:call karo|call kar|call)\s+(.+?)(?:\s+ko)?$""",
            RegexOption.IGNORE_CASE
        ).find(t) ?: Regex(
            """(.+?)\s+(?:ko\s+)?call\s+(?:karo|kar|karna|lagao)""",
            RegexOption.IGNORE_CASE
        ).find(t)
        if (callMatch != null) {
            val name = callMatch.groupValues[1].trim()
            if (name.isNotBlank() && !name.containsAny("prime", "close friend", "jaan")) {
                return AppCommand("CALL", mapOf("name" to name))
            }
        }

        // ─── SMS ───
        val smsMatch = Regex(
            """(?:sms|message|msg|text)\s+(?:bhejo|bejo|send|karo)?\s*(.+?)\s+(?:ko\s+)?(?:message|msg)?(?:\s+(.+))?$""",
            RegexOption.IGNORE_CASE
        ).find(t)
        if (smsMatch != null) {
            return AppCommand(
                "SMS", mapOf(
                    "name" to smsMatch.groupValues[1].trim(),
                    "message" to smsMatch.groupValues[2].trim()
                )
            )
        }

        // ─── Volume ───
        if (t.matchesAny("volume badhao", "volume up karo", "volume up", "awaaz badhao", "increase volume")) {
            return AppCommand("VOLUME_UP", emptyMap())
        }
        if (t.matchesAny("volume kam karo", "volume down karo", "volume down", "awaaz kam karo", "decrease volume")) {
            return AppCommand("VOLUME_DOWN", emptyMap())
        }

        // ─── Flashlight ───
        if (t.matchesAny("torch on", "torch on karo", "flashlight on", "light on karo", "light on")) {
            return AppCommand("FLASHLIGHT_ON", emptyMap())
        }
        if (t.matchesAny("torch off", "torch band karo", "flashlight off", "light off karo", "light off")) {
            return AppCommand("FLASHLIGHT_OFF", emptyMap())
        }

        // ─── Wi-Fi ───
        if (t.matchesAny("wifi on karo", "wifi on", "wi-fi on", "turn on wifi")) {
            return AppCommand("WIFI_ON", emptyMap())
        }
        if (t.matchesAny("wifi off karo", "wifi off", "wi-fi off", "turn off wifi")) {
            return AppCommand("WIFI_OFF", emptyMap())
        }

        // ─── Bluetooth ───
        if (t.matchesAny("bluetooth on karo", "bluetooth on", "bt on")) {
            return AppCommand("BLUETOOTH_ON", emptyMap())
        }
        if (t.matchesAny("bluetooth off karo", "bluetooth off", "bt off")) {
            return AppCommand("BLUETOOTH_OFF", emptyMap())
        }

        // No command matched — return null for Gemini to handle
        return null
    }

    private fun extractSecondaryIndex(text: String): Int {
        return when {
            text.contains("second") || text.contains("doosra") || text.contains("doosre") -> 1
            text.contains("third") || text.contains("teesra") -> 2
            text.contains("fourth") || text.contains("chautha") -> 3
            else -> 0
        }
    }

    private fun String.matchesAny(vararg patterns: String): Boolean =
        patterns.any { this.contains(it, ignoreCase = true) }

    private fun String.containsAny(vararg substrings: String): Boolean =
        substrings.any { this.contains(it, ignoreCase = true) }
}
