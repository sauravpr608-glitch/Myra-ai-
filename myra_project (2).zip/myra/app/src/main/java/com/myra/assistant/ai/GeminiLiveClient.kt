package com.myra.assistant.ai

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * MYRA — Gemini Live WebSocket Client
 * Handles BidiGenerateContent WebSocket connection, session renewal, keepalive, and message parsing.
 */
class GeminiLiveClient(
    private val apiKey: String,
    private val model: String,
    private val voiceName: String,
    private val systemPrompt: String,
    private val onAudioReceived: (ByteArray) -> Unit,
    private val onInputTranscript: (String) -> Unit,
    private val onOutputTranscript: (String) -> Unit,
    private val onTurnComplete: () -> Unit,
    private val onConnected: () -> Unit,
    private val onDisconnected: () -> Unit,
    private val onError: (String) -> Unit
) {
    companion object {
        private const val TAG = "GeminiLiveClient"
        private const val WS_BASE = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent"
        private const val SESSION_RENEW_AFTER = 540_000L  // 9 minutes in ms
        private const val KEEPALIVE_INTERVAL  = 8_000L    // 8 seconds in ms
        private const val RECONNECT_DELAY     = 3_000L    // 3 seconds
        private const val SILENT_PCM_CHUNK    = 1024      // bytes of silence to keep alive
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private var webSocket: WebSocket? = null
    private var isConnected = false
    private var shouldReconnect = true
    private var sessionStartTime = 0L
    private var keepAliveJob: Job? = null
    private var sessionRenewJob: Job? = null
    private var reconnectJob: Job? = null

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.SECONDS)   // No read timeout for WebSocket
        .writeTimeout(30, TimeUnit.SECONDS)
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    fun connect() {
        shouldReconnect = true
        doConnect()
    }

    private fun doConnect() {
        val url = "$WS_BASE?key=$apiKey"
        val request = Request.Builder()
            .url(url)
            .addHeader("Content-Type", "application/json")
            .build()

        Log.d(TAG, "Connecting to Gemini Live WebSocket...")

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                Log.d(TAG, "WebSocket opened")
                isConnected = true
                sessionStartTime = System.currentTimeMillis()
                sendSetupMessage(ws)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                handleServerMessage(text)
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                Log.e(TAG, "WebSocket failure: ${t.message}")
                isConnected = false
                stopPeriodicJobs()
                onDisconnected()
                onError(t.message ?: "Connection failed")
                scheduleReconnect()
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                Log.d(TAG, "WebSocket closed: $code $reason")
                isConnected = false
                stopPeriodicJobs()
                onDisconnected()
                if (shouldReconnect) scheduleReconnect()
            }
        })
    }

    private fun sendSetupMessage(ws: WebSocket) {
        val setup = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", model)
                put("system_instruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", systemPrompt) })
                    })
                })
                put("generation_config", JSONObject().apply {
                    put("response_modalities", JSONArray().apply { put("AUDIO") })
                    put("speech_config", JSONObject().apply {
                        put("voice_config", JSONObject().apply {
                            put("prebuilt_voice_config", JSONObject().apply {
                                put("voice_name", voiceName)
                            })
                        })
                    })
                    put("temperature", 0.9)
                })
                put("output_audio_transcription", JSONObject())
                put("input_audio_transcription", JSONObject())
            })
        }
        ws.send(setup.toString())
        Log.d(TAG, "Setup message sent with model=$model, voice=$voiceName")
        startPeriodicJobs()
        onConnected()
    }

    private fun handleServerMessage(text: String) {
        try {
            val json = JSONObject(text)

            // Setup complete acknowledgment
            if (json.has("setupComplete")) {
                Log.d(TAG, "Setup complete received")
                return
            }

            val serverContent = json.optJSONObject("serverContent") ?: return

            // Audio data
            val modelTurn = serverContent.optJSONObject("modelTurn")
            val parts = modelTurn?.optJSONArray("parts")
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    val inlineData = part.optJSONObject("inlineData")
                    if (inlineData != null) {
                        val mimeType = inlineData.optString("mime_type", "")
                        if (mimeType.contains("audio")) {
                            val b64data = inlineData.optString("data", "")
                            if (b64data.isNotEmpty()) {
                                val pcmBytes = Base64.decode(b64data, Base64.DEFAULT)
                                onAudioReceived(pcmBytes)
                            }
                        }
                    }
                }
            }

            // Output transcription (what MYRA said)
            val outputTranscription = serverContent.optJSONObject("outputTranscription")
            val outputText = outputTranscription?.optString("text", "")
            if (!outputText.isNullOrEmpty()) {
                onOutputTranscript(outputText)
            }

            // Input transcription (what user said)
            val inputTranscription = serverContent.optJSONObject("inputTranscription")
            val inputText = inputTranscription?.optString("text", "")
            if (!inputText.isNullOrEmpty()) {
                onInputTranscript(inputText)
            }

            // Turn complete
            if (serverContent.optBoolean("turnComplete", false)) {
                onTurnComplete()
            }

        } catch (e: Exception) {
            Log.e(TAG, "Error parsing server message: ${e.message}")
        }
    }

    /**
     * Send raw PCM audio bytes (16kHz, mono, 16-bit) to the WebSocket.
     */
    fun sendAudioChunk(pcmBytes: ByteArray) {
        if (!isConnected) return
        try {
            val b64 = Base64.encodeToString(pcmBytes, Base64.NO_WRAP)
            val msg = JSONObject().apply {
                put("realtime_input", JSONObject().apply {
                    put("media_chunks", JSONArray().apply {
                        put(JSONObject().apply {
                            put("mime_type", "audio/pcm;rate=16000")
                            put("data", b64)
                        })
                    })
                })
            }
            webSocket?.send(msg.toString())
        } catch (e: Exception) {
            Log.e(TAG, "Error sending audio: ${e.message}")
        }
    }

    /**
     * Send a text message to MYRA.
     */
    fun sendTextMessage(message: String) {
        if (!isConnected) return
        try {
            val msg = JSONObject().apply {
                put("client_content", JSONObject().apply {
                    put("turns", JSONArray().apply {
                        put(JSONObject().apply {
                            put("role", "user")
                            put("parts", JSONArray().apply {
                                put(JSONObject().apply { put("text", message) })
                            })
                        })
                    })
                    put("turn_complete", true)
                })
            }
            webSocket?.send(msg.toString())
            Log.d(TAG, "Text message sent: $message")
        } catch (e: Exception) {
            Log.e(TAG, "Error sending text: ${e.message}")
        }
    }

    /**
     * Interrupt MYRA while speaking.
     */
    fun sendInterrupt() {
        if (!isConnected) return
        try {
            val msg = JSONObject().apply {
                put("client_content", JSONObject().apply {
                    put("turns", JSONArray())
                    put("turn_complete", true)
                })
            }
            webSocket?.send(msg.toString())
            Log.d(TAG, "Interrupt sent")
        } catch (e: Exception) {
            Log.e(TAG, "Error sending interrupt: ${e.message}")
        }
    }

    private fun startPeriodicJobs() {
        stopPeriodicJobs()

        // Keepalive job: send silent PCM chunk every 8 seconds
        keepAliveJob = scope.launch {
            while (isActive && isConnected) {
                delay(KEEPALIVE_INTERVAL)
                if (isConnected) {
                    val silentChunk = ByteArray(SILENT_PCM_CHUNK) { 0 }
                    sendAudioChunk(silentChunk)
                }
            }
        }

        // Session renewal job: reconnect after 9 minutes
        sessionRenewJob = scope.launch {
            delay(SESSION_RENEW_AFTER)
            if (isActive && isConnected) {
                Log.d(TAG, "Session renewal triggered (9 min limit)")
                webSocket?.close(1000, "Session renewal")
                delay(1000)
                if (shouldReconnect) doConnect()
            }
        }
    }

    private fun stopPeriodicJobs() {
        keepAliveJob?.cancel()
        sessionRenewJob?.cancel()
        keepAliveJob = null
        sessionRenewJob = null
    }

    private fun scheduleReconnect() {
        if (!shouldReconnect) return
        reconnectJob?.cancel()
        reconnectJob = scope.launch {
            delay(RECONNECT_DELAY)
            if (isActive && shouldReconnect) {
                Log.d(TAG, "Attempting reconnect...")
                doConnect()
            }
        }
    }

    fun disconnect() {
        shouldReconnect = false
        stopPeriodicJobs()
        reconnectJob?.cancel()
        webSocket?.close(1000, "User disconnected")
        webSocket = null
        isConnected = false
    }

    fun isConnected() = isConnected

    fun destroy() {
        disconnect()
        scope.cancel()
        client.dispatcher.executorService.shutdown()
    }
}
