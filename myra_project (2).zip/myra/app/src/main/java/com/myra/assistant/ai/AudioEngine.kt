package com.myra.assistant.ai

import android.media.*
import android.util.Log
import kotlinx.coroutines.*
import java.util.concurrent.LinkedBlockingQueue
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * MYRA — Audio Engine
 * Manages PCM microphone recording (16kHz) and speaker playback (24kHz).
 * Mirrors Python sounddevice behavior with echo suppression.
 */
class AudioEngine(
    private val onAudioChunk: (ByteArray) -> Unit,
    private val onAmplitudeChanged: (Float) -> Unit
) {
    companion object {
        private const val TAG = "AudioEngine"
        // Mic config: 16kHz, Mono, PCM 16-bit
        private const val MIC_SAMPLE_RATE  = 16000
        private const val MIC_CHANNEL_IN   = AudioFormat.CHANNEL_IN_MONO
        private const val MIC_ENCODING     = AudioFormat.ENCODING_PCM_16BIT
        private const val CHUNK_SIZE       = 1024  // bytes

        // Speaker config: 24kHz, Mono, PCM 16-bit
        private const val SPK_SAMPLE_RATE  = 24000
        private const val SPK_CHANNEL_OUT  = AudioFormat.CHANNEL_OUT_MONO
        private const val SPK_ENCODING     = AudioFormat.ENCODING_PCM_16BIT
    }

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var isRecording = false
    private var isSpeaking = false   // MYRA is currently outputting audio
    private var isMuted = false

    private val playbackQueue = LinkedBlockingQueue<ByteArray>()
    private var recordJob: Job? = null
    private var playbackJob: Job? = null

    // ─────────── Recording ───────────

    fun startRecording() {
        if (isRecording) return
        val minBuffer = AudioRecord.getMinBufferSize(MIC_SAMPLE_RATE, MIC_CHANNEL_IN, MIC_ENCODING)
        val bufferSize = maxOf(minBuffer, CHUNK_SIZE * 4)

        try {
            audioRecord = AudioRecord.Builder()
                .setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setSampleRate(MIC_SAMPLE_RATE)
                        .setChannelMask(MIC_CHANNEL_IN)
                        .setEncoding(MIC_ENCODING)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .build()

            audioRecord?.startRecording()
            isRecording = true
            Log.d(TAG, "Recording started")

            recordJob = scope.launch {
                val buffer = ByteArray(CHUNK_SIZE)
                while (isActive && isRecording) {
                    val read = audioRecord?.read(buffer, 0, CHUNK_SIZE) ?: 0
                    if (read > 0) {
                        val chunk = buffer.copyOf(read)
                        // Compute RMS amplitude
                        val rms = computeRms(chunk)
                        onAmplitudeChanged(rms)
                        // Echo suppression: don't send mic while MYRA speaks
                        if (!isSpeaking && !isMuted) {
                            onAudioChunk(chunk)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start recording: ${e.message}")
        }
    }

    fun stopRecording() {
        isRecording = false
        recordJob?.cancel()
        recordJob = null
        try {
            audioRecord?.stop()
            audioRecord?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recording: ${e.message}")
        }
        audioRecord = null
        Log.d(TAG, "Recording stopped")
    }

    fun setMuted(muted: Boolean) {
        isMuted = muted
    }

    // ─────────── Playback ───────────

    fun startPlayback() {
        val minBuffer = AudioTrack.getMinBufferSize(SPK_SAMPLE_RATE, SPK_CHANNEL_OUT, SPK_ENCODING)
        val bufferSize = maxOf(minBuffer, CHUNK_SIZE * 4)

        try {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANT)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()

            val audioFormat = AudioFormat.Builder()
                .setSampleRate(SPK_SAMPLE_RATE)
                .setChannelMask(SPK_CHANNEL_OUT)
                .setEncoding(SPK_ENCODING)
                .build()

            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            audioTrack?.play()
            Log.d(TAG, "Playback started")

            playbackJob = scope.launch {
                while (isActive) {
                    val chunk = playbackQueue.poll()
                    if (chunk != null) {
                        isSpeaking = true
                        audioTrack?.write(chunk, 0, chunk.size)
                        // If queue is empty after writing, MYRA finished speaking
                        if (playbackQueue.isEmpty()) {
                            isSpeaking = false
                        }
                    } else {
                        isSpeaking = false
                        delay(5)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start playback: ${e.message}")
        }
    }

    /**
     * Enqueue PCM bytes received from Gemini for playback.
     */
    fun enqueueAudio(pcmBytes: ByteArray) {
        playbackQueue.offer(pcmBytes)
        isSpeaking = true
    }

    /**
     * Interrupt playback — clear queue and stop current audio.
     */
    fun interruptPlayback() {
        playbackQueue.clear()
        isSpeaking = false
        try {
            audioTrack?.pause()
            audioTrack?.flush()
            audioTrack?.play()
        } catch (e: Exception) {
            Log.e(TAG, "Error interrupting playback: ${e.message}")
        }
    }

    fun stopPlayback() {
        playbackQueue.clear()
        isSpeaking = false
        playbackJob?.cancel()
        playbackJob = null
        try {
            audioTrack?.stop()
            audioTrack?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping playback: ${e.message}")
        }
        audioTrack = null
        Log.d(TAG, "Playback stopped")
    }

    fun isSpeaking() = isSpeaking

    // ─────────── Helpers ───────────

    private fun computeRms(pcmBytes: ByteArray): Float {
        var sumSq = 0.0
        val len = pcmBytes.size / 2
        if (len == 0) return 0f
        for (i in 0 until len) {
            val sample = (pcmBytes[i * 2].toInt() and 0xFF) or (pcmBytes[i * 2 + 1].toInt() shl 8)
            val s = sample.toShort().toFloat()
            sumSq += s * s
        }
        val rms = sqrt(sumSq / len).toFloat()
        return (rms / 32768f).coerceIn(0f, 1f)
    }

    fun destroy() {
        stopRecording()
        stopPlayback()
        scope.cancel()
    }
}
