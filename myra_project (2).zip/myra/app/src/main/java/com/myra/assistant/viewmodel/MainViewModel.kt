package com.myra.assistant.viewmodel

import android.Manifest
import android.app.Application
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.myra.assistant.model.AppCommand
import com.myra.assistant.model.PrimeContact
import com.myra.assistant.service.AccessibilityHelperService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject

class MainViewModel(application: Application) : AndroidViewModel(application) {

    companion object {
        private const val TAG = "MainViewModel"
    }

    val commandResult = MutableLiveData<String?>()

    // ─────── App Package Map ───────
    private val appPackageMap = mapOf(
        "youtube"     to "com.google.android.youtube",
        "whatsapp"    to "com.whatsapp",
        "instagram"   to "com.instagram.android",
        "facebook"    to "com.facebook.katana",
        "chrome"      to "com.android.chrome",
        "gmail"       to "com.google.android.gm",
        "maps"        to "com.google.android.apps.maps",
        "spotify"     to "com.spotify.music",
        "netflix"     to "com.netflix.mediaclient",
        "twitter"     to "com.twitter.android",
        "x"           to "com.twitter.android",
        "telegram"    to "org.telegram.messenger",
        "snapchat"    to "com.snapchat.android",
        "settings"    to "com.android.settings",
        "calculator"  to "com.google.android.calculator",
        "calendar"    to "com.google.android.calendar",
        "clock"       to "com.google.android.deskclock",
        "phone"       to "com.google.android.dialer",
        "contacts"    to "com.google.android.contacts",
        "play store"  to "com.android.vending",
        "playstore"   to "com.android.vending",
        "amazon"      to "in.amazon.mShop.android.shopping",
        "flipkart"    to "com.flipkart.android",
        "paytm"       to "net.one97.paytm",
        "phonepe"     to "com.phonepe.app",
        "gpay"        to "com.google.android.apps.nbu.paisa.user",
        "google pay"  to "com.google.android.apps.nbu.paisa.user",
        "zoom"        to "us.zoom.videomeetings",
        "meet"        to "com.google.android.apps.meetings",
        "teams"       to "com.microsoft.teams",
        "tiktok"      to "com.zhiliaoapp.musically",
        "discord"     to "com.discord",
        "linkedin"    to "com.linkedin.android"
    )

    // ─────────── Execute Command ───────────

    fun executeCommand(command: AppCommand, primeContacts: List<PrimeContact>) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val result = when (command.type) {
                    AppCommand.OPEN_APP      -> openApp(command.params["app_name"] ?: "")
                    AppCommand.CLOSE_APP     -> closeApp()
                    AppCommand.CALL          -> makeCall(command.params["name"] ?: "")
                    AppCommand.SMS           -> sendSms(command.params["name"] ?: "", command.params["message"] ?: "")
                    AppCommand.WHATSAPP_CALL -> whatsappCall(command.params["name"] ?: "")
                    AppCommand.WHATSAPP_MSG  -> whatsappMessage(command.params["name"] ?: "", "")
                    AppCommand.PRIME_CALL    -> {
                        val idx = command.params["index"]?.toIntOrNull() ?: 0
                        val contact = primeContacts.getOrNull(idx)
                        if (contact != null) makeCallDirect(contact.number, contact.name)
                        else "No prime contact at index $idx"
                    }
                    AppCommand.PRIME_MSG     -> {
                        val idx = command.params["index"]?.toIntOrNull() ?: 0
                        val contact = primeContacts.getOrNull(idx)
                        if (contact != null) sendSmsDirect(contact.number, contact.name)
                        else "No prime contact at index $idx"
                    }
                    AppCommand.VOLUME_UP     -> adjustVolume(true)
                    AppCommand.VOLUME_DOWN   -> adjustVolume(false)
                    AppCommand.FLASHLIGHT_ON -> setFlashlight(true)
                    AppCommand.FLASHLIGHT_OFF-> setFlashlight(false)
                    AppCommand.WIFI_ON       -> setWifi(true)
                    AppCommand.WIFI_OFF      -> setWifi(false)
                    AppCommand.BLUETOOTH_ON  -> setBluetooth(true)
                    AppCommand.BLUETOOTH_OFF -> setBluetooth(false)
                    else -> "Unknown command: ${command.type}"
                }
                commandResult.postValue(result)
            } catch (e: Exception) {
                Log.e(TAG, "Command error: ${e.message}")
                commandResult.postValue("Error: ${e.message}")
            }
        }
    }

    // ─────── App Open/Close ───────

    private fun openApp(appName: String): String {
        val ctx = getApplication<Application>()
        val normalized = appName.lowercase().trim()

        // Try direct package map
        val packageName = appPackageMap[normalized]
            ?: appPackageMap.entries.firstOrNull { normalized.contains(it.key) }?.value
            ?: findAppByLabel(ctx, appName)

        if (packageName != null) {
            val intent = ctx.packageManager.getLaunchIntentForPackage(packageName)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                ctx.startActivity(intent)
                return "$appName khol diya ✅"
            }
        }
        return "$appName nahi mila 😕"
    }

    private fun findAppByLabel(ctx: Context, label: String): String? {
        val pm = ctx.packageManager
        val apps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
        val searchLabel = label.lowercase()
        return apps.firstOrNull {
            pm.getApplicationLabel(it).toString().lowercase().contains(searchLabel)
        }?.packageName
    }

    private fun closeApp(): String {
        AccessibilityHelperService.instance?.closeCurrentApp()
            ?: return "Accessibility service enabled nahi hai"
        return "App band kar diya ✅"
    }

    // ─────── Calls ───────

    private fun makeCall(name: String): String {
        val ctx = getApplication<Application>()
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.CALL_PHONE)
            != PackageManager.PERMISSION_GRANTED) {
            return "Call permission nahi hai"
        }
        val number = lookupContact(ctx, name) ?: return "$name ka number nahi mila"
        return makeCallDirect(number, name)
    }

    private fun makeCallDirect(number: String, name: String): String {
        val ctx = getApplication<Application>()
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
        return "$name ko call laga diya 📞"
    }

    fun acceptCall() {
        viewModelScope.launch(Dispatchers.Main) {
            try {
                val ctx = getApplication<Application>()
                val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ANSWER_PHONE_CALLS)
                    == PackageManager.PERMISSION_GRANTED) {
                    tm?.acceptRingingCall()
                }
            } catch (e: Exception) {
                Log.e(TAG, "acceptCall error: ${e.message}")
            }
        }
    }

    fun rejectCall() {
        viewModelScope.launch(Dispatchers.Main) {
            try {
                val ctx = getApplication<Application>()
                val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
                if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ANSWER_PHONE_CALLS)
                    == PackageManager.PERMISSION_GRANTED) {
                    tm?.endCall()
                }
            } catch (e: Exception) {
                Log.e(TAG, "rejectCall error: ${e.message}")
            }
        }
    }

    // ─────── SMS ───────

    private fun sendSms(name: String, message: String): String {
        val ctx = getApplication<Application>()
        val number = lookupContact(ctx, name) ?: return "$name ka number nahi mila"
        return sendSmsDirect(number, name)
    }

    private fun sendSmsDirect(number: String, name: String): String {
        val ctx = getApplication<Application>()
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("smsto:$number")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        ctx.startActivity(intent)
        return "$name ko message bhej diya 💬"
    }

    // ─────── WhatsApp ───────

    private fun whatsappCall(name: String): String {
        val ctx = getApplication<Application>()
        val number = lookupContact(ctx, name) ?: return "$name ka number nahi mila"
        val clean = number.replace(Regex("[^0-9+]"), "")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$clean")).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            setPackage("com.whatsapp")
        }
        try {
            ctx.startActivity(intent)
            return "$name ko WhatsApp call laga diya 📱"
        } catch (e: Exception) {
            return "WhatsApp install nahi hai"
        }
    }

    private fun whatsappMessage(name: String, message: String): String {
        val ctx = getApplication<Application>()
        val number = lookupContact(ctx, name) ?: return "$name ka number nahi mila"
        val clean = number.replace(Regex("[^0-9+]"), "")
        val encodedMsg = Uri.encode(message)
        val url = if (message.isNotBlank()) "https://wa.me/$clean?text=$encodedMsg" else "https://wa.me/$clean"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            setPackage("com.whatsapp")
        }
        try {
            ctx.startActivity(intent)
            return "$name ko WhatsApp message khol diya 💬"
        } catch (e: Exception) {
            return "WhatsApp install nahi hai"
        }
    }

    // ─────── Volume ───────

    private fun adjustVolume(up: Boolean): String {
        val ctx = getApplication<Application>()
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val direction = if (up) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
        return if (up) "Volume badha diya 🔊" else "Volume kam kar diya 🔉"
    }

    // ─────── Flashlight ───────

    private fun setFlashlight(on: Boolean): String {
        val ctx = getApplication<Application>()
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as? CameraManager ?: return "Camera nahi mila"
        return try {
            val cameraId = cm.cameraIdList.firstOrNull() ?: return "Camera nahi mila"
            cm.setTorchMode(cameraId, on)
            if (on) "Torch on kar diya 🔦" else "Torch off kar diya"
        } catch (e: Exception) {
            "Torch error: ${e.message}"
        }
    }

    // ─────── Wi-Fi ───────

    @Suppress("DEPRECATION")
    private fun setWifi(on: Boolean): String {
        val ctx = getApplication<Application>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // Android 10+ can't programmatically toggle Wi-Fi — open settings instead
            val intent = Intent(android.provider.Settings.ACTION_WIFI_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(intent)
            return "Wi-Fi settings khol diye — please manually ${if (on) "on" else "off"} karo"
        }
        val wm = ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        wm?.isWifiEnabled = on
        return if (on) "Wi-Fi on kar diya 📶" else "Wi-Fi off kar diya"
    }

    // ─────── Bluetooth ───────

    @Suppress("DEPRECATION", "MissingPermission")
    private fun setBluetooth(on: Boolean): String {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return "Bluetooth nahi mila"
        return try {
            if (on) adapter.enable() else adapter.disable()
            if (on) "Bluetooth on kar diya 🔵" else "Bluetooth off kar diya"
        } catch (e: Exception) {
            "Bluetooth error — settings mein jao"
        }
    }

    // ─────── Contact Lookup ───────

    fun lookupContact(ctx: Context, name: String): String? {
        if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) return null

        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("%$name%")

        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                null
            )?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    return cursor.getString(numberIdx)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Contact lookup error: ${e.message}")
        }
        return null
    }

    // ─────── Prime Contacts (SharedPreferences) ───────

    fun loadPrimeContacts(ctx: Context): List<PrimeContact> {
        val prefs = ctx.getSharedPreferences("myra_prefs", Context.MODE_PRIVATE)
        val json = prefs.getString("prime_contacts_json", null)

        // Legacy migration
        if (json == null) {
            val name = prefs.getString("prime_name", null)
            val number = prefs.getString("prime_number", null)
            if (!name.isNullOrBlank() && !number.isNullOrBlank()) {
                val list = listOf(PrimeContact(name, number))
                savePrimeContacts(ctx, list)
                return list
            }
            return emptyList()
        }

        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                PrimeContact(obj.getString("name"), obj.getString("number"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun savePrimeContacts(ctx: Context, contacts: List<PrimeContact>) {
        val arr = JSONArray()
        contacts.forEach { c ->
            arr.put(JSONObject().apply {
                put("name", c.name)
                put("number", c.number)
            })
        }
        ctx.getSharedPreferences("myra_prefs", Context.MODE_PRIVATE)
            .edit().putString("prime_contacts_json", arr.toString()).apply()
    }
}
